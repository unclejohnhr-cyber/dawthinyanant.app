---
title: "ကောင်မလေး ၁ ယောက်ကြောင်း"
date: 2026-03-14
category: "ပညာရေး"
tags: ["AI"]
cover: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80"
summary: "မသိဘူး ချစ်တယ်..."
---

မသိဘူး ချစ်တယ်